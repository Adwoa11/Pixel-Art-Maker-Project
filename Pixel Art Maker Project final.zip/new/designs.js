/** start by defining you form and table Elements or tags
 * you create a table using your height and width inputs
 */
const form = document.getElementById('sizePicker')
const table = document.getElementById('pixelCanvas')

function makeGrid(height, width) {
	table.innerHTML = "";

    /** create a nested loop first for row and second for height
	 * table row is created
	 * table data is created
	 * td is appended to tr using .appendchild
	 * tr is appended to table using .appendChild
	 */
	for (let i = 1; i <= height; i++) {
		const rowE = document.createElement('tr');
		for (let j = 1; j <= width; j++) {
			const colE = document.createElement('td')
			rowE.appendChild(colE)
		}
		table.appendChild(rowE)
	}
}
/** you prevent the default behaviour of a function on the DOM
	 * you empty the table Element of its children if any
	 * you get value of ur height and width using the .value property
	 */
function makingGrid(evt){
	evt.preventDefault()
	const height = document.getElementById('inputHeight').value
	const width = document.getElementById('inputWidth').value
	makeGrid(height, width)
}

/** an eventListener is created on the form which listens to submit and calls makeGrid function
 * an eventListener is created on the table which listens to clicks on the td of table. and calls change color function
 */
form.addEventListener('submit', makingGrid)

/** function changeColor is created.
 */

function changeColor(evt) {
	evt.preventDefault()

	let color = document.getElementById('colorPicker').value
	evt.target.style.backgroundColor = color

}

table.addEventListener('click', changeColor)